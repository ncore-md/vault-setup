#!/bin/bash
# Install LLM Wiki pre-commit hook.
# Run this once after setting up the wiki tooling.

HOOKS_DIR="$(git rev-parse --show-toplevel)/.githooks"
GIT_HOOKS_DIR="$(git rev-parse --git-dir)/hooks"

mkdir -p "$HOOKS_DIR"
cp "$HOOKS_DIR/pre-commit" "$GIT_HOOKS_DIR/pre-commit"
chmod +x "$GIT_HOOKS_DIR/pre-commit"

echo "Pre-commit hook installed to $GIT_HOOKS_DIR/pre-commit"
git config core.hooksPath "$HOOKS_DIR"
